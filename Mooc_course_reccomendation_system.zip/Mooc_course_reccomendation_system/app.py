from flask import Flask, render_template, request, redirect, url_for, flash
import pandas as pd
import os

app = Flask(__name__)
app.secret_key = 'a_very_secret_key'  # Replace with a secure key

# File paths for datasets
COURSES_FILE_PATH = r'F:\Mooc_course_reccomendation_system\datasets\MOOC.xlsx'
USER_DATA_FILE_PATH = r'F:\Mooc_course_reccomendation_system\datasets\mooc_user_data.ods'

# Load datasets
if os.path.exists(COURSES_FILE_PATH):
    courses_df = pd.read_excel(COURSES_FILE_PATH, engine='openpyxl')
else:
    courses_df = pd.DataFrame()  # Initialize as empty if file doesn't exist

if os.path.exists(USER_DATA_FILE_PATH):
    user_data_df = pd.read_excel(USER_DATA_FILE_PATH, engine='odf')
else:
    user_data_df = pd.DataFrame(columns=[
        'User ID', 'Name', 'Email', 'Age', 'Country',
        'Occupation', 'Learning Goals', 'Preferred Topics',
        'Preferred Difficulty Level', 'Skills Acquired', 'Password'
    ])

# Function for content-based recommendation (stub, implement your logic)
def content_based_recommendation(preferred_topics, courses_df):
    # Sample recommendation logic based on preferred topics
    recommendations = []
    if preferred_topics:
        # Search for courses related to preferred topics
        recommendations = courses_df[courses_df['Course Name'].str.contains(preferred_topics, case=False, na=False)]
    return recommendations.to_dict(orient='records')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    global user_data_df
    if request.method == 'POST':
        try:
            # Extract form data
            user_id = request.form['user_id']
            
            # Check if user ID already exists
            if user_id in user_data_df['User ID'].values:
                flash("This User ID already exists. Please choose a different one.", "danger")
                return redirect(url_for('register'))

            password = request.form['password']
            confirm_password = request.form['confirm_password']
            
            # Check if password and confirm password match
            if password != confirm_password:
                flash("Passwords do not match.", "danger")
                return redirect(url_for('register'))

            # Add new user data
            user_data = {
                'User ID': user_id,
                'Name': request.form['name'],
                'Email': request.form['email'],
                'Age': int(request.form['age']),
                'Country': request.form['country'],
                'Occupation': request.form['occupation'],
                'Learning Goals': request.form['learning_goals'],
                'Preferred Topics': request.form['preferred_topics'],
                'Preferred Difficulty Level': request.form['preferred_difficulty'],
                'Skills Acquired': request.form['skills_acquired'],
                'Password': password
            }

            # Append the new user data to the DataFrame
            user_data_df = pd.concat([user_data_df, pd.DataFrame([user_data])], ignore_index=True)

            # Save the updated DataFrame back to the ODS file
            user_data_df.to_excel(USER_DATA_FILE_PATH, index=False, engine='odf')

            flash("Registration successful! Your profile has been saved.", "success")
            return redirect(url_for('home'))
        except Exception as e:
            flash(f"Error during registration: {str(e)}", "danger")
            return redirect(url_for('register'))

    return render_template('register.html')


@app.route('/recommendation', methods=['GET', 'POST'])
def recommendation():
    recommendations = []
    user_authenticated = False
    login_error = None

    if request.method == 'POST':
        user_id = request.form.get('user_id')
        password = request.form.get('password')

        # Check login credentials
        if user_id and password:
            user_row = user_data_df[user_data_df['User ID'] == user_id]
            if not user_row.empty and user_row.iloc[0]['Password'] == password:
                user_authenticated = True
            else:
                login_error = "Invalid User ID or Password. Please try again."

        # If authenticated, generate recommendations based on preferred topics
        if user_authenticated:
            preferred_topics = request.form.get('preferred_topics')
            recommendations = content_based_recommendation(preferred_topics, courses_df)

            if not recommendations:
                flash("No recommendations found for the selected topics.", "info")
        else:
            # If not authenticated, we don't show recommendations
            return render_template('recommendation.html', login_error=login_error, user_authenticated=False)

    return render_template('recommendation.html', recommendations=recommendations, user_authenticated=user_authenticated, login_error=login_error)


if __name__ == '__main__':
    app.run(debug=True)
